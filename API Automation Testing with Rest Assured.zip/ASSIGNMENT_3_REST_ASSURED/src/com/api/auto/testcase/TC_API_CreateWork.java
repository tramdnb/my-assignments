package com.api.auto.testcase;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.api.auto.utils.AssertionUtils;
import com.api.auto.utils.JsonFileUtils;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_API_CreateWork {
	private Response response;
	private ResponseBody<?> responseBody;
	private String token = JsonFileUtils.getToken();
	private String nameWork;
	private String experience;
	private String education;
	
	@BeforeClass
	public void inIt() {
	// Lấy giá trị cấu hình từ tệp JSON
	    Map<String, String> config = JsonFileUtils.getProperty();
	    
	    String baseUrl = config.get("baseUrl");
	    String createWorkPath = config.get("createWorkPath"); 
	    nameWork = config.get("nameWork"); 
	    experience = config.get("experience");
	    education = config.get("education");
	    
		RestAssured.baseURI = baseUrl;
	// Tạo body
		Map<String, Object> body = new HashMap<String, Object>();
		body.put("nameWork", nameWork);
		body.put("experience", experience);
		body.put("education", education);
		
		RequestSpecification request = RestAssured.given()
				.contentType(ContentType.JSON)
				.header("token",token)
				.body(body);
		
		response = request.post(createWorkPath);
		responseBody = response.body();
		
		
		// Thiết lập giá trị response cho AssertionUtils
        AssertionUtils.setResponse(response);
        System.out.println("TC_API_CreateWork");
		System.out.println("Response: "+responseBody.asPrettyString());
	}
	
	@Test(priority=0)
	public void TC01_Validate201Created() {
	// kiểm chứng status code
		AssertionUtils.assertResponseStatusCode(201);
	}
	
	@Test(priority=1)
	public void TC02_ValidateWordId() {
	// kiểm chứng id
		AssertionUtils.assertFieldExists("id");;
	}
	
	@Test(priority=2)
	public void TC03_ValidateNameOfWorkMatched() {
	// kiểm chứng tên công việc nhận được có giống lúc tạo	
		AssertionUtils.assertFieldMatching("nameWork",nameWork);
	}
	
	@Test(priority=3)
	public void TC04_ValidateExperienceMatched() {
	// kiểm chứng kinh nghiệm nhận được có giống lúc tạo
		AssertionUtils.assertFieldMatching("experience",experience);
	}
	
	@Test(priority=4)
	public void TC05_ValidateEducationMatched() {
	// kiểm chứng học vấn nhận được có giống lúc tạo
		AssertionUtils.assertFieldMatching("education",education);
	}
}
