package com.api.auto.testcase;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.api.auto.utils.AssertionUtils;
import com.api.auto.utils.JsonFileUtils;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_API_Login {
	
	private Response response;
	private ResponseBody<?> responseBody;
	private JsonPath bodyJson;
	private String account;
	private String password;
	
	
	@BeforeClass
	public void inIt() {
		
	// Lấy giá trị cấu hình từ tệp JSON
	    Map<String, String> config = JsonFileUtils.getProperty();
	    
	    String baseUrl = config.get("baseUrl");
	    String loginPath = config.get("loginPath");
	    account = config.get("account");
	    password = config.get("password");
		
		RestAssured.baseURI = baseUrl;

	// Tạo body
		Map<String, Object> body = new HashMap<String,Object>();
		body.put("account", account);
		body.put("password", password);
		
		RequestSpecification request = RestAssured.given()
				.contentType(ContentType.JSON)
				.body(body);
		response = request.post(loginPath);
		responseBody = response.body();
		bodyJson = responseBody.jsonPath();
	// Thiết lập giá trị response cho AssertionUtils
        AssertionUtils.setResponse(response);
        System.out.println("TC_API_Login");
		System.out.println("Response: "+responseBody.asPrettyString());
	}

	@Test(priority=0)
	// kiểm chứng status code
	public void TC01_Validate200Ok() {
		AssertionUtils.assertResponseStatusCode(200);
	}
	
	@Test(priority=1)
	public void TC02_ValidateMessage() {	
	// kiểm chứng response body có chứa trường message
		AssertionUtils.assertFieldExists("message");
	// kiểm chứng trường message có = "Đăng nhập thành công"
		AssertionUtils.assertFieldMatching("message", "Đăng nhập thành công");
	}
	
	@Test(priority=2)
	public void TC03_ValidateToken() {
	// kiểm chứng response body có chứa trường token hay không
		String token = bodyJson.getString("token");
		JsonFileUtils.saveToken(token); // lưu lại token
		AssertionUtils.assertFieldExists("token");
	}
   
    
	@Test(priority=3)
	public void TC04_ValidateUserType() {
	// kiểm chứng response body có chứa thông tin user
		AssertionUtils.assertFieldExists("user");
	// kiểm chứng trường type của user
		AssertionUtils.assertFieldMatching("user.type", "UNGVIEN");
	}
	
	@Test(priority=4)
	public void TC05_ValidateAccount() {
    // Kiểm chứng trường account của user
		AssertionUtils.assertFieldExists("user.account");
		AssertionUtils.assertFieldMatching("user.account", account);
    // Kiểm chứng trường password của user	
		AssertionUtils.assertFieldExists("user.password");
		AssertionUtils.assertFieldMatching("user.password", password);
	}
}
