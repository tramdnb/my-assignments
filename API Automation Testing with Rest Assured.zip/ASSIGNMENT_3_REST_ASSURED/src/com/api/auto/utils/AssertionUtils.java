package com.api.auto.utils;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class AssertionUtils {
	private static Response response;
	private static ResponseBody<?> responseBody;
	private static JsonPath bodyJson;
	
	//Lấy dữ liệu response
    public static void setResponse(Response response) {
        AssertionUtils.response = response;
        AssertionUtils.responseBody = response.body();
        AssertionUtils.bodyJson = responseBody.jsonPath();
    }
    //xác thực statuc code
	public static void assertResponseStatusCode(int expectedStatusCode) {
		assertEquals(response.getStatusCode(), expectedStatusCode, "Status check failed!");
	}
	
	//Xác thực trường tồn tại
	public static void assertFieldExists(String field) {
		if(responseBody.asString().contains(field)) {
	    assertTrue(true);
		}else if(bodyJson.getString(field) != null) {
		assertTrue(true);
		} assertFalse(false, field + " field does not exist!");
	}

	//Xác thực trường có giá trị trùng khớp với dữ liệu mong muốn
	public static void assertFieldMatching(String field, String expectedValue) {
		String actualValue = bodyJson.getString(field);
		if (actualValue == null) {
			actualValue = "";
		}
		assertEquals(actualValue, expectedValue, field + " is not matched!");
	}
}
