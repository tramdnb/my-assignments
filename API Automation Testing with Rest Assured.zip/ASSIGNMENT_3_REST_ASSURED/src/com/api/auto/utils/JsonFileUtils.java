package com.api.auto.utils;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonFileUtils {
	//Đường dẫn
	private static String CONFIG_PATH = "./configuration/configs.json";
	private static String TOKEN_PATH = "./configuration/token.json";
	private static ObjectMapper objectMapper = new ObjectMapper();
	
	//Đọc cấu hình từ tệp
	public static Map<String, String> getProperty() {
		try {
			return objectMapper.readValue(
					new File(CONFIG_PATH),new TypeReference<Map<String, String>>() {});
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	//Lưu token
	public static void saveToken(String token) {
		Map<String,String> tokenData = new HashMap<>();
		tokenData.put("token", token);
		// Sử dụng ObjectMapper để ghi dữ liệu từ Map vào tệp TOKEN_PATH
		try {
			objectMapper.writeValue(new File(TOKEN_PATH), tokenData);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//Lấy token
	public static String getToken() {
		try {
			// Sử dụng ObjectMapper để đọc nội dung từ tệp TOKEN_PATH 
			Map<String,String> tokenData = objectMapper.readValue(
					//và chuyển đổi nó thành Map<String, String>
					new File(TOKEN_PATH),new TypeReference<Map<String, String>>() {});
			return tokenData.get("token");
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}
