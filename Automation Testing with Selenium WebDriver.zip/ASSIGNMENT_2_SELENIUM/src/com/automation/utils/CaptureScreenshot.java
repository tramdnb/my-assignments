package com.automation.utils;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

public class CaptureScreenshot {
	static String filePath = null;
	public static void takeScreenshot(WebDriver driver, String name){
		
        try {            
            TakesScreenshot screenshot = (TakesScreenshot) driver;
            File sourceFile = screenshot.getScreenshotAs(OutputType.FILE);           
            filePath = "./Screenshots/"+name+".png";
            File destFile = new File(filePath);
            FileUtils.copyFile(sourceFile, destFile);
		
		} catch (Exception e) {
			System.out.println("Đã xảy ra lỗi khi chụp ảnh màn hình");
		}
		
	}
	
	public static void attachScreenshotToReport(){
		 try {
	            System.setProperty("org.uncommons.reportng.escape-output", "false");
	            File file = new File(filePath);            
	            Reporter.log(
	                "<br><a title= \"ScreenShot\" href=\"" + file.getAbsoluteFile() + "\">" +
	                "<img alt='"+file.getName()+"' src='"+file+"' height='243' width='418'></a></br>");
	        } catch (Exception e) {
	            System.out.println("Đã xảy ra lỗi khi đính kèm ảnh vào báo cáo");
	     }
	}
}
