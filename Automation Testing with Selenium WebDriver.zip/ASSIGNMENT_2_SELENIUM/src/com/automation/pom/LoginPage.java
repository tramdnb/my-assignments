package com.automation.pom;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.automation.utils.PropertiesFileUtils;

public class LoginPage {
	private static WebDriverWait wait;
	protected WebDriver driver = null;
	private static String emailLocator = PropertiesFileUtils.getProperty("login_email_name");
	private static String passwordLocator = PropertiesFileUtils.getProperty("login_pasword_name");
	private static String siginLocator = PropertiesFileUtils.getProperty("login_signin_xpath");
	private static String loginLocator = PropertiesFileUtils.getProperty("icon_login_xpath");
	private static String logoutLocator = PropertiesFileUtils.getProperty("icon_logout_xpath");
	
	public LoginPage (WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver,Duration.ofSeconds(30));
	}
	
	public void enterEmail(String email) throws InterruptedException {
		try {
		WebElement inputEmail = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.name(emailLocator)));
		inputEmail.sendKeys(email);
		Thread.sleep(2000);
		}catch(Exception e) {
			e.printStackTrace();
			Assert.fail("Không thể nhập dữ liệu vào trường email. Lỗi: " + e.getMessage());
		}
	}
	
	public void enterPassword(String password) throws InterruptedException {
		try {
		WebElement inputPassword = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.name(passwordLocator)));
		inputPassword.sendKeys(password);
		Thread.sleep(2000);
		}catch(Exception e) {
			e.printStackTrace();
			Assert.fail("Không thể nhập dữ liệu vào trường password. Lỗi: " + e.getMessage());
		}
	}
	
	public void clickSignin() throws InterruptedException {
		try {
		WebElement buttonSignin = wait.until(ExpectedConditions.elementToBeClickable(
				By.xpath(siginLocator)));
		buttonSignin.click();
		Thread.sleep(2000);
		}catch(Exception e) {
			e.printStackTrace();
			Assert.fail("Không thể click Signin. Lỗi: " + e.getMessage());
		}
	}
	
	public void clickLogin() throws InterruptedException {
		try {
		WebElement buttonLogin = wait.until(ExpectedConditions.elementToBeClickable(
				By.xpath(loginLocator)));
		buttonLogin.click();
		Thread.sleep(2000);
		}catch(Exception e) {
			e.printStackTrace();
			Assert.fail("Không thể click Login. Lỗi: " + e.getMessage());
		}
	}
	
	public void clickLogout() throws InterruptedException {
		try {
		WebElement buttonLogout = wait.until(ExpectedConditions.elementToBeClickable(
				By.xpath(logoutLocator)));
		buttonLogout.click();
		Thread.sleep(2000);
		}catch(Exception e) {
			e.printStackTrace();
			Assert.fail("Không thể click Logout. Lỗi: " + e.getMessage());
		}
	}
}
