package com.automation.testcase;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.automation.base.DriverInstance;
import com.automation.pom.LoginPage;
import com.automation.utils.CaptureScreenshot;
import com.automation.utils.PropertiesFileUtils;

public class TC_LoginTest extends DriverInstance{

	@Test(dataProvider = "Excel")
	public void TC01_LoginAccount(String email, String password) throws InterruptedException {
		LoginPage loginPage = new LoginPage(driver);	
		driver.get(PropertiesFileUtils.getProperty("url"));
		
		loginPage.clickLogin();
		loginPage.enterEmail(email);
		loginPage.enterPassword(password);
		loginPage.clickSignin();		
		loginPage.clickLogout();
		Thread.sleep(2000);
	}
	
	@DataProvider(name="Excel")
	public Object [][] testDataGenerator()throws IOException {
		FileInputStream file = new FileInputStream("./Data/assignment2_data_test.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheet("Login");
		int numberOfData = sheet.getPhysicalNumberOfRows();
		Object [][] data = new Object[numberOfData][2];
		
		for (int i = 0; i < numberOfData; i++) {
			XSSFRow row = sheet.getRow(i);
			XSSFCell email = row.getCell(0);
			XSSFCell password = row.getCell(1);
			data[i][0] = email.getStringCellValue();
			data[i][1] = password.getStringCellValue();
		}
		workbook.close();
		return data;
	}
	
	@AfterMethod
	public void takeScheenshot(ITestResult result) throws InterruptedException{
		if(ITestResult.FAILURE == result.getStatus()) {
			try {
				String email = (String)result.getParameters()[0];
				int index = email.indexOf('@');
				String accountName = email.substring(0,index);			
				CaptureScreenshot.takeScreenshot(driver, accountName);
				CaptureScreenshot.attachScreenshotToReport();
				System.out.println("Chụp ảnh màn hình testcase FAILED: "+accountName+".png");
			}catch(Exception e) {
				System.out.println("Đã xảy ra lỗi khi chụp ảnh màn hình:"+e.getMessage());
				e.printStackTrace();	
			}
		}
	}
}
