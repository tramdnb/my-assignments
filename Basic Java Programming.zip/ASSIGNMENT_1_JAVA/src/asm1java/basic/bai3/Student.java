package asm1java.basic.bai3;

public class Student {
	 private String fullName;
	 private String address;
	 private String dob;
	 private String gender;
	 private float finalGrade;
	 private char continueInput;
	 
	 public String getFullName() {
		 return fullName;
	 }
	 public void setFullName(String fullName) {
		 if (!fullName.matches("[a-zA-Z\\s]+")|| fullName.contains("\n")) {
	         throw new IllegalArgumentException("Invalid full name");
	        }
		 this.fullName = fullName;
	 }
	 public String getAddress() {
		 return address;
	 }
	 public void setAddress(String address) {
		 if (address.isEmpty()){
			 throw new IllegalArgumentException("Invalid address");
		 }
		 this.address = address;
	 }
	 public String getDob() {
		 return dob;
	 }
	 public void setDob(String dob) {
		 if (!dob.matches("\\d{2}/\\d{2}/\\d{4}")|| dob.contains("\n")) {
	         throw new IllegalArgumentException("Invalid date of birth (dd/mm/yyyy)");
		 }
		 this.dob = dob;
	 }
	 public String getGender() {
		 return gender;
	 }
	 public void setGender(String gender) {
		 if (gender.isEmpty()){
			 throw new IllegalArgumentException("Invalid gender");
		 }
		 this.gender = gender;
	 }
	 public float getFinalGrade() {
		 return finalGrade;
	 }
	 public void setFinalGrade(float finalGrade) {
		 this.finalGrade = finalGrade;
	 }
	 public char getContinueInput() {
		 return continueInput;
	 }
	 public void setContinueInput(char continueInput) {
		 if (continueInput != 'Y' && continueInput != 'N') {
	            throw new IllegalArgumentException("Invalid continue input, please enter Y or N");
	        }
		 this.continueInput = continueInput;
	 }
}
