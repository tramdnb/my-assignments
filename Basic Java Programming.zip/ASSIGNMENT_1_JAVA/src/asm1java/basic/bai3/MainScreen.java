package asm1java.basic.bai3;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MainScreen {
	public static void main(String[] args) {
		ArrayList<Student> studentList = new ArrayList<Student>();
		Scanner scanner = new Scanner(System.in);
		char continueInput;
		do {
			Student student = new Student();
			try {	
				System.out.print("Enter full name: ");
				String fullName = scanner.nextLine(); 
				student.setFullName(fullName);
			
				System.out.print("Enter address: ");
				String address = scanner.nextLine(); 
				student.setAddress(address);
			
				System.out.print("Enter date of birth (dd/mm/yyyy): ");
				String dob = scanner.nextLine(); 
				student.setDob(dob);
			
				System.out.print("Enter gender: ");
				String gender = scanner.nextLine(); 
				student.setGender(gender);
			
				System.out.print("Enter final grade: ");			
				while (true) {
                    try {
                        float finalGrade = scanner.nextFloat();
                        if (finalGrade >= 0 && finalGrade <= 10) {
                            student.setFinalGrade(finalGrade);
                            break;
                        } else {
                            System.out.println("Error: Invalid final grade. "
                            		+ "Please enter a grade between 0 and 10.");
                        }
                        
                    } catch (InputMismatchException e) {
                        System.out.println("Error: Invalid input. "
                        		+ "Please enter a valid Number for final grade.");
                        scanner.nextLine();
                    }
				}
				studentList.add(student);
				scanner.nextLine();
				System.out.println();
				System.out.print("Do you want to continue? (Y/N) ");
				System.out.println();
				continueInput = Character.toUpperCase(scanner.nextLine().charAt(0));
				student.setContinueInput(continueInput);
			} catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
                System.out.println("The student information was not recorded.\n");

                System.out.print("Do you want to continue? (Y/N) ");
                continueInput = Character.toUpperCase(scanner.nextLine().charAt(0));
			}
		} while (continueInput=='Y');
		System.out.println();
		System.out.println("Student List:");
		for (int i = 0; i < studentList.size(); i++) {
			Student student = studentList.get(i);			
			System.out.println("Student " + (i+1) + ":");			
			System.out.println("Full Name: " + student.getFullName());
			System.out.println("Address: " + student.getAddress());
			System.out.println("DOB: " + student.getDob());
			System.out.println("Gender: " + student.getGender());
			System.out.println("Final grade: " + student.getFinalGrade());
			
			float finalGrade = student.getFinalGrade();
			String hocLuc = null;
			
			if (finalGrade < 4.0) {
				hocLuc = "học lực kém";
			} else if (finalGrade < 5.0) {
				hocLuc = "học lực yếu";
			} else if (finalGrade < 5.5) {
				hocLuc = "học lực trung bình yếu";
			} else if (finalGrade < 6.5) {
				hocLuc = "học lực trung bình";
			} else if (finalGrade < 7.0) {
				hocLuc = "học lực trung bình khá";
			} else if (finalGrade < 8.0) {
				hocLuc = "học lực khá";
			} else if (finalGrade < 8.5) {
				hocLuc = "học lực khá giỏi";
			} else if (finalGrade <= 10.0){
				hocLuc = "học lực giỏi";
			}
			System.out.println("Học sinh " + student.getFullName()+" "+ hocLuc);							
			System.out.println();
			
		}
		float totalGrade = 0;
		for (int i = 0; i < studentList.size(); i++){
			Student student = studentList.get(i);
			totalGrade += student.getFinalGrade();
		}
		
		float averageGrade = totalGrade/studentList.size();
		System.out.println("\nĐiểm tổng kết trung bình của danh sách học sinh: "
				+ averageGrade);
		scanner.close();
	}
}
