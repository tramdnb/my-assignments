package asm1java.basic.bai1;

public class CalculateUtils {
	 public static double tinhCong(double x, double y) {
		return x+y;	 
	 }
	 public static double tinhNhan(double x, double y) {
		return x*y;	 
	 }
	 public static double tinhTru(double x, double y) {
		return x-y;	 
	 }
	 public static double tinhChia(double x, double y) {
		 if (y == 0) {
		        throw new ArithmeticException("Số chia y phải khác 0");
		    }
		    return x / y;
		}	 
	 }
	 
	