package asm1java.basic.bai1;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MyMainClass {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        double x = 0;
	        double y = 0;

	        try {
	            System.out.print("Nhập số thứ nhất x = ");
	            x = scanner.nextDouble();

	            System.out.print("Nhập số thứ hai y = ");
	            y = scanner.nextDouble();
	            System.out.println();
	        } catch (InputMismatchException ex) {
	            System.out.println("Giá trị nhập vào không phải là số");
	            scanner.close();
	            return;
	        }

	        scanner.nextLine();

	        System.out.print("Nhập một lệnh ACTION trong danh sách sau:  “CONG” , “TRU”,  “NHAN”, “CHIA” \n ACTION = ");
	        String action = scanner.nextLine().toUpperCase();
	        double result = 0;

	        if (action.equals("CONG")) {
	            result = CalculateUtils.tinhCong(x, y);
	        } else if (action.equals("TRU")) {
	            result = CalculateUtils.tinhTru(x, y);
	        } else if (action.equals("NHAN")) {
	            result = CalculateUtils.tinhNhan(x, y);
	        } else if (action.equals("CHIA")) {
	            try {
	                result = CalculateUtils.tinhChia(x, y);
	            } catch (ArithmeticException ex) {
	                System.out.println(ex.getMessage());
	                scanner.close();
	                return;
	            }
	        } else {
	            System.out.println("Giá trị ACTION không hợp lệ");
	            scanner.close();
	            return;
	        }
	        System.out.println();
	        System.out.println("Kết quả: " + result);

	        scanner.close();
	    }
	}
